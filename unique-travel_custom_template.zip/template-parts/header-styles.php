<!-- header styles -->

<?php
   $localFonts = apply_filters('get_local_fonts', '');
?>
<?php if ($localFonts) : ?> 
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/<?php echo $localFonts; ?>" media="screen" type="text/css" />
<?php else : ?>
   <?php endif; ?>
<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
<style> .u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 112px;
}
.u-header .u-image-1 {
  width: 480px;
  height: 123px;
  margin: -11px 313px 0 auto;
}
.u-header .u-image-2 {
  width: 97px;
  height: 90px;
  margin: -88px auto 0 0;
}
.u-header .u-logo-image-1 {
  width: 100%;
  height: 100%;
}
.u-header .u-menu-1 {
  margin: -32px 0 24px auto;
}
.u-header .u-nav-1 {
  font-weight: 500;
  font-size: 1rem;
  letter-spacing: normal;
}
.u-header .u-nav-2 {
  font-size: 1.25rem;
}
@media (max-width: 1199px) {
  .u-header .u-image-1 {
    margin-top: -106px;
    margin-right: 313px;
  }
  .u-header .u-image-2 {
    width: 97px;
    height: 90px;
    margin-top: -88px;
  }
  .u-header .u-menu-1 {
    margin-top: -32px;
  }
}
@media (max-width: 991px) {
  .u-header .u-image-1 {
    margin-right: 240px;
  }
}
@media (max-width: 767px) {
  .u-header .u-image-1 {
    margin-right: 60px;
  }
}
@media (max-width: 575px) {
  .u-header .u-sheet-1 {
    min-height: 76px;
  }
  .u-header .u-image-1 {
    width: 340px;
    height: 87px;
    margin-right: 0;
  }
  .u-header .u-image-2 {
    margin-top: -52px;
  }
}</style>
