<footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-bc7d">
  <div class="u-clearfix u-sheet u-sheet-1"></div>
</footer>